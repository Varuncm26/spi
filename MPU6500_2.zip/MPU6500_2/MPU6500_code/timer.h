#ifndef TIMER_H
#define TIMER_H

#include "boardfile.h"
#include <stdlib.h>
#include <cross_studio_io.h>

#define ARR32MAX 0xffffffff - 1
#define ARR16MAX 0xffff - 1

#define PSC_VALUE_0 0
#define PSC_VALUE_9 9
#define PSC_VALUE_99 99
#define PSC_VALUE_999 999
#define PSC_VALUE_9999 9999
#define PSC_COUNT 5


typedef struct{
  uint32_t busFreq;
  float resolution;
  float timerFreq;
  uint32_t Prescaler;
  uint64_t AutoReload;
  uint16_t counterResolution;  //16 or 32 bit

  uint16_t index;
  uint32_t counterMode;
  //uint32_t ClockDivision;
}timer_t;

extern timer_t timer2, timer5;
extern timer_t wallClockTimer;

void timerInit(timer_t *t,TIM_TypeDef *TIMx, float timerFreq_hz,uint32_t counterMode);
void timerInterruptEnable(TIM_TypeDef *TIMx,uint32_t setPriority);
void timerWallClockInit(timer_t *t,TIM_TypeDef *TIMx,uint32_t counterMode);
//for test
void timergpio(void);


#endif