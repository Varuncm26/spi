#include "boardfile.h"
//#include "serial.h"
#include <stdint.h>


//CONTAINS THE CONFIGURATIONS OF THE MICROCONTROLLER





uint8_t spi1TXBuffer[SPI_BUFFER_TX_SIZE];
uint8_t spi1RXBuffer[SPI_BUFFER_RX_SIZE];
uint8_t spi2TXBuffer[SPI_BUFFER_TX_SIZE];
uint8_t spi2RXBuffer[SPI_BUFFER_RX_SIZE];

SPI_TypeDef *SPIS[NUM_SPI] =                     {SPI1,SPI2};
uint32_t SPI_SCK_PIN[NUM_SPI] =                  {LL_GPIO_PIN_5,LL_GPIO_PIN_13};
uint32_t SPI_MISO_PIN[NUM_SPI] =                 {LL_GPIO_PIN_6,LL_GPIO_PIN_14};
uint32_t SPI_MOSI_PIN[NUM_SPI] =                 {LL_GPIO_PIN_7,LL_GPIO_PIN_15};
GPIO_TypeDef *SPI_SCK_PORT[NUM_SPI] =            {GPIOA,GPIOB};
GPIO_TypeDef *SPI_MISO_PORT[NUM_SPI] =           {GPIOA,GPIOB};
GPIO_TypeDef *SPI_MOSI_PORT[NUM_SPI]=            {GPIOA,GPIOB};
uint32_t SPI_GPIO_AF[NUM_SPI] =                  {5,5};
uint32_t SPI_RX_DMA_STREAM[NUM_SPI] =            {0,3};
uint32_t SPI_TX_DMA_STREAM[NUM_SPI] =            {3,4};
DMA_TypeDef *SPI_TX_DMA_NUMBER[NUM_SPI] =        {DMA2,DMA1};
DMA_TypeDef *SPI_RX_DMA_NUMBER[NUM_SPI] =        {DMA2,DMA1};
uint32_t SPI_RX_DMA_CHANNEL[NUM_SPI] =           {LL_DMA_CHANNEL_3,LL_DMA_CHANNEL_0};
uint32_t SPI_TX_DMA_CHANNEL[NUM_SPI] =           {LL_DMA_CHANNEL_3,LL_DMA_CHANNEL_0};
uint8_t* SPIBUFFERTX[NUM_SPI] =                  {spi1TXBuffer, spi2TXBuffer};
uint8_t* SPIBUFFERRX[NUM_SPI] =                  {spi1RXBuffer,spi2RXBuffer};



//uint32_t SPI1_CS_PIN[SPI1_CS_NUM] =                   {LL_GPIO_PIN_0}; 
//GPIO_TypeDef *SPI1_CS_PORT[SPI1_CS_NUM] =             {GPIOB};

uint32_t SPI_CS_PIN[NUM_SPI] = { LL_GPIO_PIN_0, 0 }; 
GPIO_TypeDef *SPI_CS_PORT[NUM_SPI] = { GPIOB, 0 };


// Exti pin mapping
uint32_t EXTI_PIN =          {LL_GPIO_PIN_0};
GPIO_TypeDef *EXTI_PORT =    {GPIOA};
uint32_t EXTI_SYSCFG_PORT =  {LL_SYSCFG_EXTI_PORTA};
uint32_t EXTI_SYSCFG_LINE=  {LL_SYSCFG_EXTI_LINE0};



TIM_TypeDef *TIMER[NUM_TIMERS] =                   {TIM1,TIM2,TIM3,TIM4,TIM5};
uint32_t BUS_FREQUENCY[NUM_TIMERS] =               {84000000,84000000,84000000,84000000,84000000}; //Frequency in Hz
uint16_t COUNTER_RESOLUTION[NUM_TIMERS] =          {16,32,16,16,32}; // 16 or 32
