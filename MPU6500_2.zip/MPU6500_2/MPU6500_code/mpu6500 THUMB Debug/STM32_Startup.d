mpu6500\ THUMB\ Debug/STM32_Startup.o: \
 C:/Users/myself/AppData/Local/Rowley\ Associates\ Limited/CrossWorks\ for\ ARM/v4/packages/targets/STM32/STM32_Startup.s \
 C:/Users/myself/AppData/Local/Rowley\ Associates\ Limited/CrossWorks\ for\ ARM/v4/packages/targets/STM32/STM32F411xE.vec
