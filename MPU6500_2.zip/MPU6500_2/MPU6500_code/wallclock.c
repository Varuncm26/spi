#include "wallclock.h"
#include <string.h>
#include "stm32f4xx_ll_tim.h"
#include "stm32f4xx_ll_bus.h"
#include "timer.h"

typedef struct {
	volatile uint16_t hour;
	volatile uint16_t mins;
	volatile uint32_t sec;
	volatile uint32_t millis;
	volatile uint32_t micros;
	TIM_TypeDef *timer;
} clock_t;

delay_t delay;

clock_t clock;


void wallClockInit(TIM_TypeDef *TIMx) {
	memset(&clock, 0, sizeof(clock_t));
	clock.timer = TIMx;
	timerWallClockInit(&wallClockTimer,TIMx,LL_TIM_COUNTERMODE_UP);
}


void wallClockUpdate() {

	uint32_t cnt = clock.timer->CNT;
	if (cnt < clock.micros) {
		clock.millis += 0xffffffff / 1000;
	}
	clock.micros = cnt;

}

uint32_t wallClockGetTimeMillis() {
	return (clock.millis + clock.micros / 1000);
}

uint32_t timerMillis() {
	return wallClockGetTimeMillis();
}


uint32_t wallClockGetTimeMicros(TIM_TypeDef *TIMx) {
	return TIMx->CNT;
}
uint32_t timerMicros(){
     return wallClockGetTimeMicros(TIM5);
}

void wallClockWait(uint32_t mills) {
	//NOT TO BE USED in an IRQ
	//BLOCKING WAIT
	uint32_t startTime = wallClockGetTimeMillis();
	while (wallClockGetTimeMillis() - startTime < mills);
}

uint8_t wallClockNonBlockWait(uint32_t mills){
     
    if (delay.waitFlag == 0){
		delay.waitFlag = 1;
		delay.startTime = wallClockGetTimeMillis();
                return 0; 
     }
    else
	if (delay.waitFlag){
    	if (wallClockGetTimeMillis() - delay.startTime < mills)
			return 0;
    	else{
			delay.waitFlag = 0;
			return 1;
		}

    }
    	
}


void delay_ms(uint32_t ms) {
    uint32_t start = timerMicros();
    uint32_t target = ms * 1000;  // Convert ms to μs
    
    while ((timerMicros() - start) < target) {
        // Blocking wait
    }
}

void delay_us(uint32_t us) {
    uint32_t start = timerMicros();
    
    while ((timerMicros() - start) < us) {
        // Blocking wait
    }
}