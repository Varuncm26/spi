#include <stdio.h>
#include "boardfile.h"
#include "clock_init.h"
#include "spi.h"
#include "exti.h"
#include "mpu6500.h"
#include "mpuRegister.h"
#include "wallclock.h"




int main(void) 
 {
    // INITIALIZE CLOCKS
    clockInit();
   wallClockInit(TIM5);
 

    //  INITIALIZE SPI HARDWARE
  spiData = spiInit(
        SPI1, 
        LL_SPI_BAUDRATEPRESCALER_DIV8, 
        3,                              
        LL_SPI_DATAWIDTH_8BIT, 
        LL_SPI_NSS_SOFT, 
        LL_SPI_MSB_FIRST, 
        LL_SPI_MODE_MASTER, 
        LL_SPI_FULL_DUPLEX,
        spiRxCallBack);

     //INITIALIZE CLOCKS
       timerInit(&timer2,TIM2,1000,LL_TIM_COUNTERMODE_UP);
       timerInterruptEnable(TIM2,0);
    

      // INITIALIZE THE MPU-6500
   //mpu6500Init(&mpuint, GYRO_FS_500DPS, ACCEL_FS_4G, 0);
  

  // // ENABLE HARDWARE INTERRUPTS

     //extiInit();
uint8_t myTxData;
myTxData = 0x80 | MPU6500_REG_WHO_AM_I; 

     
    //uint8_t reg = 1|MPU6500_REG_WHO_AM_I;
    // MAIN LOOP
    while (1) 
    {

      spiTransact(spiData,&myTxData, 2);
   //   delay_ms(100);

         //mpu6500Read(&mpuint, MPU6500_REG_ACCEL_XOUT_H, 14);
       
        
        //printf("Accel: X:%.2f  Y:%.2f  Z:%.2f | Gyro: X:%.2f  Y:%.2f  Z:%.2f\n",
        //       mpuint.mpuData.ax, mpuint.mpuData.ay, mpuint.mpuData.az,
        //       mpuint.mpuData.gx, mpuint.mpuData.gy, mpuint.mpuData.gz);
  
        //}
}
}

void EXTI0_IRQHandler(void)
{
    // Check the interrupt 
    if (LL_EXTI_IsActiveFlag_0_31(MPU_INT_EXTI_LINE) != RESET) 
    {
        LL_EXTI_ClearFlag_0_31(MPU_INT_EXTI_LINE); // Clear the flag 
        
        //spiProcessRx(spiData);
        //// Data read form sensor
        //mpu6500Read(&mpuint, MPU6500_REG_ACCEL_XOUT_H, 15); 
        
    }
}    


void TIM2_IRQHandler(void)
{
  if(LL_TIM_IsActiveFlag_UPDATE(TIM2)){
     LL_TIM_ClearFlag_UPDATE(TIM2);
     wallClockUpdate();
     

     }
}
