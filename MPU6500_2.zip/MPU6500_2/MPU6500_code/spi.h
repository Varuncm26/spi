#ifndef SPI_H
#define SPI_H

#include "stm32f4xx_ll_gpio.h"
#include "stm32f4xx_ll_dma.h"
#include "dma.h"
#include "timer.h"
#include "boardfile.h"

#include <stdlib.h>
#include <string.h>
#include <cross_studio_io.h>


//// CS for sensor1
//#define CS1_PIN LL_GPIO_PIN_0
//#define CS1_PORT GPIOB 
////CS for sensor2
//#define CS2_PIN LL_GPIO_PIN_1
//#define CS2_PORT GPIOB
////CS for sensor3
//#define CS3_PIN LL_GPIO_PIN_2
//#define CS3_PORT GPIOB

typedef struct {
    uint16_t* data;
    uint32_t size;
    uint8_t  type;
} spiSendItem_t;

enum SPIMsgType{
 SPI_TELEMETRY_MESSAGE = 0,
 SPI_NOTICE_MESSAGE,
 SPI_TEST_MESSAGE
};

typedef enum{
  SPI_IDLE,
  SPI_PROCESSING
}spiStatus_t; 

typedef uint32_t SpiRxCallBack_t(uint8_t *data, uint32_t size);

typedef struct {

    SPI_TypeDef *SPIx;

    uint8_t  *spiBufferRx;
    uint8_t  *spiBufferTx;
    volatile uint16_t txHead;
    volatile uint16_t txTail;
    volatile uint16_t rxHead;
    volatile uint16_t rxTail;

    uint8_t spiIndex;
    uint8_t csNum;

    spiSendItem_t sendList[SPI_LIST_SIZE];
    uint8_t tempRxBuf[SPI_BUFFER_RX_SIZE];
    uint8_t rxProcessed;

    // GPIO info
    uint32_t csPin;
    uint32_t  sckPin;
    uint32_t  misoPin;
    uint32_t  mosiPin;
    GPIO_TypeDef *csPort;
    GPIO_TypeDef *sckPort;
    GPIO_TypeDef *misoPort;
    GPIO_TypeDef *mosiPort;
    uint32_t  afType;

    // DMA info
    DMA_TypeDef *txDMAx;
    DMA_TypeDef *rxDMAx;
    uint32_t     txDMAStreamNumber;
    uint32_t     rxDMAStreamNumber;
    uint32_t     txDMAChannel;
    uint32_t     rxDMAChannel;

    uint8_t   spiStatus;

    SpiRxCallBack_t *rxCallBack;
} spiPort_t;

extern spiPort_t* spiData;


spiPort_t *spiInit(SPI_TypeDef *SPIx,uint32_t baudPrescaler, uint32_t spiMode, uint32_t datasize, uint32_t nss, 
                     uint32_t firstbit, uint32_t master,uint32_t direction,SpiRxCallBack_t *rxCallBack);

void spiProcessRx(spiPort_t* s);
void spiTx(spiPort_t *s, uint8_t* buffer, uint32_t length);
void spiSendListItem(spiPort_t* s);
void spiScheduleTx(spiPort_t *s, uint16_t* buffer, uint32_t length);

void spiRX(spiPort_t* s);
void spiCSInit(GPIO_TypeDef *CSPort, uint32_t CSPin);
void spiCSLow(spiPort_t* s);
void spiCSHigh(spiPort_t* s);



uint32_t spiRxCallBack(uint8_t *data, uint32_t len);

 void spiTransact(spiPort_t *s, uint8_t *txBuffer, uint32_t length);
             

         

#endif