#include "mpu6500.h"
#include "spi.h"
#include "mpuRegister.h"
#include "wallclock.h"
#include <stdio.h>


mpu6500_t mpuint;

//void scaleFactor()
//{
//      switch (cfg->gyro_fs) {
//        case MPU6500_GYRO_FS_250DPS:  mpu->gyroScale = 1.0f / 131.0f;  break;
//        case MPU6500_GYRO_FS_500DPS:  mpu->gyroScale = 1.0f / 65.5f;   break;
//        case MPU6500_GYRO_FS_1000DPS: mpu->gyroScale = 1.0f / 32.8f;   break;
//        case MPU6500_GYRO_FS_2000DPS: mpu->gyroScale = 1.0f / 16.4f;   break;
//        default:                      mpu->gyroScale = 1.0f / 131.0f;  break;
//    }

//    switch (cfg->accel_fs) {
//        case MPU6500_ACCEL_FS_2G:  mpu->accelScale = 1.0f / 16384.0f; break;
//        case MPU6500_ACCEL_FS_4G:  mpu->accelScale = 1.0f / 8192.0f;  break;
//        case MPU6500_ACCEL_FS_8G:  mpu->accelScale = 1.0f / 4096.0f;  break;
//        case MPU6500_ACCEL_FS_16G: mpu->accelScale = 1.0f / 2048.0f;  break;
//        default:                   mpu->accelScale = 1.0f / 16384.0f; break;
//    }


//}


//void mpu6500Read(mpu6500_t *mpu,uint8_t reg,uint8_t len)
//{
//  uint16_t buf;
//  buf = READ_FLAG |(reg & 0x7f);
//  spiCSLow(spiData);
//  spiScheduleTx(spiData,&buf,len);    
//  spiCSHigh(spiData);


//}

//void mpu6500Write(mpu6500_t *mpu,uint8_t reg,uint8_t data,uint8_t len)
//{ 
//  uint16_t txBuffer;
//  txBuffer = WRITE_FLAG |(reg & 0x7f)<<7|data;
//  //txBuffer[1] = data;
//  spiCSLow(spiData);
//  spiScheduleTx(spiData,&txBuffer,len);    
//  spiCSHigh(spiData);
//}

void mpu6500Read(mpu6500_t *mpu,uint8_t reg,uint8_t len)
{

mpu->txBuffer[0] = READ_FLAG | (reg & 0x7F);
   memset(&mpu->txBuffer[1], 0x00, len);
    spiCSLow(spiData);
    spiScheduleTx(spiData,(uint16_t*) mpu->txBuffer, len );
}

void mpu6500Write(mpu6500_t *mpu,uint8_t reg,uint8_t data,uint8_t len)
{
    mpu->txBuffer[0] = WRITE_FLAG | (reg & 0x7F);
    mpu->txBuffer[1] = data;
  spiCSLow(spiData);
    spiScheduleTx(spiData,(uint16_t*) mpu->txBuffer, len); 
}


void mpu6500SetScaleFactors(mpu6500_t *mpu, uint32_t gyroFs, uint32_t accelFs) 
{
    // scale for the Gyroscope
    switch (gyroFs) {
        case GYRO_FS_250DPS:  mpu->gyroScale = 1.0f / 131.0f;  break;
        case GYRO_FS_500DPS:  mpu->gyroScale = 1.0f / 65.5f;   break;
        case GYRO_FS_1000DPS: mpu->gyroScale = 1.0f / 32.8f;   break;
        case GYRO_FS_2000DPS: mpu->gyroScale = 1.0f / 16.4f;   break;
        default:              mpu->gyroScale = 1.0f / 131.0f;  break;
    }

    // scale for the Accelerometer
    switch (accelFs) {
        case ACCEL_FS_2G:  mpu->accelScale = 1.0f / 16384.0f; break;
        case ACCEL_FS_4G:  mpu->accelScale = 1.0f / 8192.0f;  break;
        case ACCEL_FS_8G:  mpu->accelScale = 1.0f / 4096.0f;  break;
        case ACCEL_FS_16G: mpu->accelScale = 1.0f / 2048.0f;  break;
        default:           mpu->accelScale = 1.0f / 16384.0f; break;
    }
}

uint8_t mpu6500Init(mpu6500_t* mpu,uint32_t gyroFs,uint32_t accelFs, uint8_t smplrtDiv)
{
  /*  1. who am i(read)
      2. device reset(write) & reset signal path
      3. wakeup clock source (write)
      4. disable I2C 
      5. sample rate divider
      6. config-dlfp, gyro config,accel config
      7. INT interrupt

  */
  // 1 WHO_AM_I:
   
   //mpu6500Read(mpu, MPU6500_REG_WHO_AM_I, 1);

     
  // 2 MPU6500_RESET:
    mpu6500Write(mpu, MPU6500_REG_PWR_MGMT_1, MPU_BIT_DEVICE_RESET, 2);
    delay_ms(100);
    // Reset Signal Path
    
    uint8_t sigPathResetParams = (MPU_BIT_GYRO_RST | MPU_BIT_ACCEL_RST | MPU_BIT_TEMP_RST);
    mpu6500Write(mpu, MPU6500_REG_SIGNAL_PATH_RESET, sigPathResetParams, 2);
   delay_ms(100);

    // 3 Wake Up & Set Clock Source

    mpu6500Write(mpu, MPU6500_REG_PWR_MGMT_1, MPU_CLKSEL_AUTO, 2);
    delay_ms(10);
    // 4 Disable I2C Interface
   
    mpu6500Write(mpu, MPU6500_REG_USER_CTRL, MPU_BIT_I2C_IF_DIS, 2);

    // 5 Set Sample Rate Divider
    mpu->smplrtDiv = smplrtDiv;
    mpu6500Write(mpu, MPU6500_REG_SMPLRT_DIV, mpu->smplrtDiv, 2);

    // 6 General Configuration / DLPF
   
    mpu6500Write(mpu, MPU6500_REG_CONFIG, DLPF_41HZ, 2);

    //  Gyroscope Configuration
    
    mpu6500Write(mpu, MPU6500_REG_GYRO_CONFIG, (gyroFs << MPU_GYRO_FS_SHIFT), 2);

    //  Accelerometer Configuration
    
    mpu6500Write(mpu, MPU6500_REG_ACCEL_CONFIG, (accelFs << MPU_ACCEL_FS_SHIFT), 2);

    // 7 Configure Interrupt and Enable Raw Data Interrupt
    
    uint8_t intPinConfig = (MPU_BIT_LATCH_INT_EN | MPU_BIT_INT_ANYRD_2CLEAR);
    mpu6500Write(mpu, MPU6500_REG_INT_PIN_CFG, intPinConfig, 2);
    
    mpu6500Write(mpu, MPU6500_REG_INT_ENABLE, MPU_BIT_RAW_RDY_EN, 2);

    // 8 Assign Math Scale Factors
    mpu6500SetScaleFactors(mpu, gyroFs, accelFs);



//    mpu6500Read(&mpuint, MPU6500_REG_ACCEL_XOUT_H, 14); 
   printf("MPU6500 Init SUCCESS\n");
    return 1; // Initialization successful
}

uint8_t mpu6500ReadData(mpu6500_t *mpu,uint8_t *data) 
{
   //mpu->rxbuffer = data;
   memcpy(mpu->rxbuffer, data, 15);
    //  Store the RAW data by combining High and Low bytes
    mpu->rawData.ax   = (int16_t)((mpu->rxbuffer[1] << 8)  | mpu->rxbuffer[2]);
    mpu->rawData.ay   = (int16_t)((mpu->rxbuffer[3] << 8)  | mpu->rxbuffer[4]);
    mpu->rawData.az   = (int16_t)((mpu->rxbuffer[5] << 8)  | mpu->rxbuffer[6]);
    
    mpu->rawData.temp = (int16_t)((mpu->rxbuffer[7] << 8)  | mpu->rxbuffer[8]);
    
    mpu->rawData.gx   = (int16_t)((mpu->rxbuffer[9] << 8)  | mpu->rxbuffer[10]);
    mpu->rawData.gy   = (int16_t)((mpu->rxbuffer[11] << 8) | mpu->rxbuffer[12]);
    mpu->rawData.gz   = (int16_t)((mpu->rxbuffer[13] << 8) | mpu->rxbuffer[14]);

    //  Convert raw values to physical units 
    mpu->mpuData.ax = (float)mpu->rawData.ax * mpu->accelScale;
    mpu->mpuData.ay = (float)mpu->rawData.ay * mpu->accelScale;
    mpu->mpuData.az = (float)mpu->rawData.az * mpu->accelScale;

    mpu->mpuData.gx = (float)mpu->rawData.gx * mpu->gyroScale;
    mpu->mpuData.gy = (float)mpu->rawData.gy * mpu->gyroScale;
    mpu->mpuData.gz = (float)mpu->rawData.gz * mpu->gyroScale;

    // Convert Temperature to Celsius
    mpu->mpuData.temp = ((float)mpu->rawData.temp / 333.87f) + 21.0f;
   
    return 1;
}
