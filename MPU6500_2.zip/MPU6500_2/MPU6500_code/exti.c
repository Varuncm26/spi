#include "exti.h"
#include "boardfile.h"
#include "mpu6500.h"

exti_t extiData;

void extiInit(void) 
{
      LL_GPIO_InitTypeDef GPIO_InitStruct;

      extiData.extiPort = EXTI_PORT;
      extiData.extiPin = EXTI_PIN;

    // Connect EXTI Line to the GPIO Pin
    LL_SYSCFG_SetEXTISource(MPU_SYSCFG_PORT, MPU_SYSCFG_LINE);

      LL_GPIO_StructInit(&GPIO_InitStruct);
      GPIO_InitStruct.Pin = extiData.extiPin;
      GPIO_InitStruct.Mode = LL_GPIO_MODE_INPUT;
      GPIO_InitStruct.Speed = LL_GPIO_SPEED_FREQ_HIGH;
      GPIO_InitStruct.OutputType = LL_GPIO_OUTPUT_PUSHPULL;
      GPIO_InitStruct.Pull = LL_GPIO_PULL_DOWN;
      LL_GPIO_Init(extiData.extiPort, &GPIO_InitStruct);

    // Configure EXTI Line for Rising Edge Trigger
    LL_EXTI_EnableIT_0_31(MPU_INT_EXTI_LINE);
    LL_EXTI_EnableRisingTrig_0_31(MPU_INT_EXTI_LINE);

    // Enable the Interrupt in the NVIC
    NVIC_SetPriority(MPU_INT_IRQn, 0);
    NVIC_EnableIRQ(MPU_INT_IRQn);
}

