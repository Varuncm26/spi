#include "spi.h"
#include "mpu6500.h"
#include <stdio.h>

spiPort_t* spiData;



uint8_t findSpiIndex(SPI_TypeDef *SPI){
 for (int spi_index = 0; spi_index < NUM_SPI; spi_index++)
    {
      if(SPI == SPIS[spi_index])
        return spi_index;
  }

  return 0;
}

//uint8_t findCsNum(spiPort_t *s,SPI_TypeDef *SPI){
//  if(SPI == SPI1)
//     s->csNum = SPI1_CS_NUM;
//  else if(SPI == SPI2)
//     s->csNum = 0; //spi2 cs macro
//  else 
//     s->csNum =0;  //spi3 cs macro
//  return 1;
//}

spiPort_t *spiInit(SPI_TypeDef *SPIx, uint32_t baudPrescaler, uint32_t spiMode, uint32_t datasize, uint32_t nss, uint32_t firstbit, uint32_t master,uint32_t direction,SpiRxCallBack_t *rxCallBack)
{

   LL_SPI_InitTypeDef SPI_InitStruct;
   LL_GPIO_InitTypeDef GPIO_InitStruct;
   LL_DMA_InitTypeDef DMA_InitStruct;

    spiPort_t *s = (spiPort_t *)calloc(1, sizeof(spiPort_t));


    s->spiIndex = findSpiIndex(SPIx);
    //s->csNum = findCsNum(s,SPIx);
    s->SPIx = SPIx;

   // Assign pins, ports from arrays
    s->csPin = SPI_CS_PIN[s->spiIndex];
    s->csPort =SPI_CS_PORT[s->spiIndex];
    s->sckPin = SPI_SCK_PIN[s->spiIndex];
    s->misoPin = SPI_MISO_PIN[s->spiIndex];
    s->mosiPin = SPI_MOSI_PIN[s->spiIndex];
    s->sckPort = SPI_SCK_PORT[s->spiIndex];
    s->misoPort = SPI_MISO_PORT[s->spiIndex];
    s->mosiPort = SPI_MOSI_PORT[s->spiIndex];
    s->afType = SPI_GPIO_AF[s->spiIndex];

    //assign DMA from arrays
    s->spiBufferRx = SPIBUFFERRX[s->spiIndex];
    s->rxDMAx = SPI_RX_DMA_NUMBER[s->spiIndex];
    s->rxDMAStreamNumber = SPI_RX_DMA_STREAM[s->spiIndex];
    s->rxDMAChannel = SPI_RX_DMA_CHANNEL[s->spiIndex];

    s->spiBufferTx = SPIBUFFERTX[s->spiIndex];
    s->txDMAx = SPI_TX_DMA_NUMBER[s->spiIndex];
    s->txDMAStreamNumber = SPI_TX_DMA_STREAM[s->spiIndex];
    s->txDMAChannel = SPI_TX_DMA_CHANNEL[s->spiIndex];
    s->rxCallBack = rxCallBack;

      // SPI Peripheral Init
    LL_SPI_StructInit(&SPI_InitStruct);
    SPI_InitStruct.BaudRate = baudPrescaler;
    SPI_InitStruct.ClockPolarity = (spiMode & 0x2) ? LL_SPI_POLARITY_HIGH : LL_SPI_POLARITY_LOW; // Mode 2/3 => CPOL=1
    SPI_InitStruct.ClockPhase = (spiMode & 0x1) ? LL_SPI_PHASE_2EDGE : LL_SPI_PHASE_1EDGE;       // Mode 1/3 => CPHA=1
    SPI_InitStruct.DataWidth = datasize;
    SPI_InitStruct.TransferDirection = direction; 
    SPI_InitStruct.NSS = nss;
    SPI_InitStruct.BitOrder = firstbit;
    SPI_InitStruct.Mode = master;               
    LL_SPI_Init(SPIx, &SPI_InitStruct);
    LL_SPI_Enable(SPIx);

    //GPIO Pin Init for CS
  // for(int i=0;i< s->csNum;i++){
      LL_GPIO_StructInit(&GPIO_InitStruct);
      GPIO_InitStruct.Pin = s->csPin;
      GPIO_InitStruct.Mode = LL_GPIO_MODE_OUTPUT;
      GPIO_InitStruct.Speed = LL_GPIO_SPEED_FREQ_HIGH;
      GPIO_InitStruct.OutputType = LL_GPIO_OUTPUT_PUSHPULL;
      GPIO_InitStruct.Pull = LL_GPIO_PULL_NO;
      LL_GPIO_Init(s->csPort, &GPIO_InitStruct);

      LL_GPIO_SetOutputPin(s->csPort, s->csPin);     //setting high as default
  //  }

    // GPIO Pin Init for SCK
    LL_GPIO_StructInit(&GPIO_InitStruct);
    GPIO_InitStruct.Pin = s->sckPin;
    GPIO_InitStruct.Mode = LL_GPIO_MODE_ALTERNATE;
    GPIO_InitStruct.Speed = LL_GPIO_SPEED_FREQ_HIGH;
    GPIO_InitStruct.Alternate = s->afType;
    LL_GPIO_Init(s->sckPort, &GPIO_InitStruct);
  

    // GPIO Pin Init for MOSI
    GPIO_InitStruct.Pin = s->mosiPin;
    LL_GPIO_Init(s->mosiPort, &GPIO_InitStruct);

    // GPIO Pin Init for MISO
    GPIO_InitStruct.Pin = s->misoPin;
    LL_GPIO_Init(s->misoPort, &GPIO_InitStruct);

    //// DMA for TX
    LL_DMA_StructInit(&DMA_InitStruct);
    DMA_InitStruct.PeriphOrM2MSrcAddress = (uint32_t)&(SPIx->DR);
    DMA_InitStruct.MemoryOrM2MDstAddress = (uint32_t)(s->spiBufferTx);
    //DMA_InitStruct.NbData = SPI_BUFFER_TX_SIZE;
    DMA_InitStruct.PeriphOrM2MSrcIncMode = LL_DMA_PERIPH_NOINCREMENT;
    DMA_InitStruct.MemoryOrM2MDstIncMode = LL_DMA_MEMORY_INCREMENT;
    DMA_InitStruct.Direction = LL_DMA_DIRECTION_MEMORY_TO_PERIPH;
    DMA_InitStruct.Mode = LL_DMA_MODE_NORMAL;
    DMA_InitStruct.Channel = s->txDMAChannel;
    LL_DMA_Init(s->txDMAx, s->txDMAStreamNumber, &DMA_InitStruct);

    // DMA for RX
    LL_DMA_StructInit(&DMA_InitStruct);
    DMA_InitStruct.PeriphOrM2MSrcAddress = (uint32_t)&(SPIx->DR);
    DMA_InitStruct.MemoryOrM2MDstAddress = (uint32_t)(s->spiBufferRx);
 //   DMA_InitStruct.NbData = SPI_BUFFER_RX_SIZE;
    DMA_InitStruct.PeriphOrM2MSrcIncMode = LL_DMA_PERIPH_NOINCREMENT;
    DMA_InitStruct.MemoryOrM2MDstIncMode = LL_DMA_MEMORY_INCREMENT;
    DMA_InitStruct.Direction = LL_DMA_DIRECTION_PERIPH_TO_MEMORY;
    DMA_InitStruct.Mode = LL_DMA_MODE_NORMAL;
    DMA_InitStruct.Channel = s->rxDMAChannel;
    //DMA_InitStruct.MemoryOrM2MDstDataSize = LL_DMA_MDATAALIGN_HALFWORD;
    //DMA_InitStruct.PeriphOrM2MSrcDataSize = LL_DMA_PDATAALIGN_HALFWORD;
    LL_DMA_Init(s->rxDMAx, s->rxDMAStreamNumber, &DMA_InitStruct);

    //LL_DMA_EnableStream(s->rxDMAx, s->rxDMAStreamNumber);
    //LL_DMA_EnableStream(s->txDMAx, s->txDMAStreamNumber);

    //LL_SPI_EnableDMAReq_TX(SPIx);
    //LL_SPI_EnableDMAReq_RX(SPIx);

    return s;
}

//void spiCSInit(GPIO_TypeDef *CSPort, uint32_t CSPin){
//   LL_GPIO_InitTypeDef GPIO_InitStruct;

// LL_GPIO_StructInit(&GPIO_InitStruct);
//    GPIO_InitStruct.Pin = CSPin;
//    GPIO_InitStruct.Mode = LL_GPIO_MODE_OUTPUT;
//    GPIO_InitStruct.Speed = LL_GPIO_SPEED_FREQ_HIGH;
//    GPIO_InitStruct.OutputType = LL_GPIO_OUTPUT_PUSHPULL;
//    GPIO_InitStruct.Pull = LL_GPIO_PULL_NO;
//  LL_GPIO_Init(CSPort, &GPIO_InitStruct);
//  LL_GPIO_SetOutputPin(CSPort,CSPin);     //setting high as default
//}

void spiCSLow(spiPort_t* s) {
    LL_GPIO_ResetOutputPin(s->csPort,s->csPin);
}

void spiCSHigh(spiPort_t* s) {
    LL_GPIO_SetOutputPin(s->csPort, s->csPin);
}




void spiTransact(spiPort_t *s, uint8_t *txBuffer, uint32_t length)
{
  if (s->spiStatus == SPI_PROCESSING) {
        return; 
    }

  LL_DMA_DisableStream(s->txDMAx, s->txDMAStreamNumber);
  LL_DMA_DisableStream(s->rxDMAx, s->rxDMAStreamNumber);
 

  DMA_ClearFlag_TC(s->txDMAx, s->txDMAStreamNumber);
  DMA_ClearFlag_TC(s->rxDMAx, s->rxDMAStreamNumber);

  //LL_DMA_SetMemoryAddress(s->txDMAx, s->txDMAStreamNumber, (uint32_t)txBuffer);
  memcpy(s->spiBufferTx, txBuffer,length);
  LL_DMA_SetMemoryAddress(s->rxDMAx, s->rxDMAStreamNumber, (uint32_t)s->spiBufferRx);

  LL_DMA_SetDataLength(s->txDMAx, s->txDMAStreamNumber, length);
  LL_DMA_SetDataLength(s->rxDMAx, s->rxDMAStreamNumber, length);

  spiCSLow(s);
  s->spiStatus = SPI_PROCESSING;

  LL_DMA_EnableStream(s->rxDMAx, s->rxDMAStreamNumber);
  LL_SPI_EnableDMAReq_RX(s->SPIx);
  LL_DMA_EnableStream(s->txDMAx, s->txDMAStreamNumber);
  LL_SPI_EnableDMAReq_TX(s->SPIx);
  if (DMA_IsActiveFlag_TC(s->txDMAx, s->txDMAStreamNumber))
  {
    DMA_ClearFlag_TC(s->txDMAx, s->txDMAStreamNumber);
  }
  if (DMA_IsActiveFlag_TC(s->rxDMAx, s->rxDMAStreamNumber))
  {
   DMA_ClearFlag_TC(s->rxDMAx, s->rxDMAStreamNumber);
   spiCSHigh(s);
    s->rxCallBack(s->spiBufferRx, length);


  };
  
  s->spiStatus = SPI_IDLE;

      
}




uint32_t spiRxCallBack(uint8_t *data, uint32_t len) 
{
if(len>1){

for(int i=0;i<len;i++)
  printf("data: %lu \n",data[i]);
return len;
}
}


//void spiRX(spiPort_t* s){
//LL_DMA_SetDataLength(s->rxDMAx, s->rxDMAStreamNumber, SPI_BUFFER_RX_SIZE);
//     LL_DMA_EnableStream(s->rxDMAx, s->rxDMAStreamNumber);

//while (DMA_IsActiveFlag_TC(s->rxDMAx, s->rxDMAStreamNumber) == 0);
//    DMA_ClearFlag_TC(s->rxDMAx, s->rxDMAStreamNumber);
//    s->rxCallBack()
//  }


//void spiTx(spiPort_t *s, uint8_t* buffer, uint32_t length)
//{
//LL_DMA_SetMemoryAddress(s->txDMAx, s->txDMAStreamNumber, (uint32_t)buffer);
//    LL_DMA_SetDataLength(s->txDMAx, s->txDMAStreamNumber, length);
//    LL_DMA_EnableStream(s->txDMAx, s->txDMAStreamNumber);

// while (DMA_IsActiveFlag_TC(s->txDMAx, s->txDMAStreamNumber) == 0);
//    DMA_ClearFlag_TC(s->txDMAx, s->txDMAStreamNumber);
    
//}

//void spiProcessRx(spiPort_t* s){
//  int i, j;
//  int bytesRead =	0;
//  int unprocessedDataLength;
//  //ndtr holds number of bytes remaining to be transferred.
//  int ndtr = LL_DMA_GetDataLength(s->rxDMAx, s->rxDMAStreamNumber);

//  s->rxHead = SPI_BUFFER_RX_SIZE - ndtr;
//  if (s->rxHead >	s->rxTail) {
//      unprocessedDataLength = s->rxHead - s->rxTail;
//      bytesRead = s->rxCallBack(&s->spiBufferRx[s->rxTail], unprocessedDataLength);
//  } else if (s->rxHead < s->rxTail) {
//      unprocessedDataLength = s->rxHead + SPI_BUFFER_RX_SIZE	- s->rxTail;
//      memcpy(&s->tempRxBuf[0], &s->spiBufferRx[s->rxTail], SPI_BUFFER_RX_SIZE - s->rxTail);
//      memcpy(&s->tempRxBuf[SPI_BUFFER_RX_SIZE - s->rxTail], &s->spiBufferRx[0], s->rxHead);
//      bytesRead = s->rxCallBack(s->tempRxBuf,unprocessedDataLength);
//  }
//  s->rxTail = (s->rxTail + bytesRead) % SPI_BUFFER_RX_SIZE;
//}

 
//void spiSendListItem(spiPort_t* s) {
//    if (DMA_IsActiveFlag_TC(s->txDMAx, s->txDMAStreamNumber) && (s->spiStatus == SPI_PROCESSING)) {
//           DMA_ClearFlag_TC(s->txDMAx, s->txDMAStreamNumber);
//        s->txTail = (s->txTail + 1) % SPI_LIST_SIZE;
//        s->spiStatus = SPI_IDLE;
        
//    }
//    if ((s->txHead != s->txTail) && s->spiStatus == SPI_IDLE) {
//        LL_DMA_SetMemoryAddress(s->txDMAx, s->txDMAStreamNumber, (uint32_t)s->sendList[s->txTail].data);
//        LL_DMA_SetDataLength(s->txDMAx, s->txDMAStreamNumber, s->sendList[s->txTail].size);
//        LL_DMA_EnableStream(s->txDMAx, s->txDMAStreamNumber);
//        s->spiStatus = SPI_PROCESSING;
//    }
//}




//// Schedule a transmit item (queue it)
//void spiScheduleTx(spiPort_t *s, uint16_t* buffer, uint32_t length) {
//    s->sendList[s->txHead].data = buffer;
//    s->sendList[s->txHead].size = length;
//    s->txHead = (s->txHead + 1) % SPI_LIST_SIZE;
//}




