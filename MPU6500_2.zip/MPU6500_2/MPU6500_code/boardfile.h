//CONTAINS PREPROCESSORS THAT NEEDS TO BE IN BOARDFILE
#include <stdint.h>
#include "stm32f4xx_ll_dma.h"
#include "stm32f4xx_ll_gpio.h"
#include "stm32f4xx_ll_usart.h"
#include "stm32f4xx_ll_spi.h"
#include "stm32f4xx_ll_bus.h"
#include "stm32f4xx.h"
#include "stm32f4xx_ll_tim.h"
#include "stm32f4xx_ll_system.h"
#include "stm32f4xx_ll_exti.h"

#ifndef  BOARD_FILE_H
#define  BOARD_FILE_H

#define SERIAL_LIST_SIZE 110

#define NUM_SPI 2
#define SPI1_CS_NUM 1

#define SPI_LIST_SIZE 15
#define SPI_BUFFER_RX_SIZE 15
#define SPI_BUFFER_TX_SIZE 2

#define NUM_TIMERS 5

#define NUM_EXTI 1  // exti



extern SPI_TypeDef *SPIS[NUM_SPI];                          
extern uint32_t SPI_SCK_PIN[NUM_SPI];
extern uint32_t SPI_MISO_PIN[NUM_SPI];
extern uint32_t SPI_MOSI_PIN[NUM_SPI];
extern GPIO_TypeDef *SPI_SCK_PORT[NUM_SPI];
extern GPIO_TypeDef *SPI_MISO_PORT[NUM_SPI];
extern GPIO_TypeDef *SPI_MOSI_PORT[NUM_SPI];           
extern uint32_t SPI_GPIO_AF[NUM_SPI];                   
extern uint32_t SPI_RX_DMA_STREAM[NUM_SPI];             
extern uint32_t SPI_TX_DMA_STREAM[NUM_SPI];             
extern DMA_TypeDef *SPI_TX_DMA_NUMBER[NUM_SPI];        
extern DMA_TypeDef *SPI_RX_DMA_NUMBER[NUM_SPI];        
extern uint32_t SPI_RX_DMA_CHANNEL[NUM_SPI]; 
extern uint32_t SPI_TX_DMA_CHANNEL[NUM_SPI];
extern uint8_t* SPIBUFFERTX[NUM_SPI];
extern uint8_t* SPIBUFFERRX[NUM_SPI];

extern uint32_t SPI_CS_PIN[NUM_SPI];
extern GPIO_TypeDef *SPI_CS_PORT[NUM_SPI];

extern TIM_TypeDef *TIMER[NUM_TIMERS];
extern uint32_t BUS_FREQUENCY[NUM_TIMERS];
extern uint16_t COUNTER_RESOLUTION[NUM_TIMERS];

// --- EXTI CONFIGURATION ---

extern uint32_t EXTI_PIN;
extern GPIO_TypeDef *EXTI_PORT;
extern uint32_t EXTI_SYSCFG_PORT;
extern uint32_t EXTI_SYSCFG_LINE;


#endif
