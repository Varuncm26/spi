#ifndef _WALLCLOCK_H
#define _WALLCLOCK_H

#include <stdlib.h>
#include "timer.h"


extern void wallClockInit(TIM_TypeDef *TIMx);

typedef struct{
  uint8_t waitFlag;
  uint32_t startTime;
  }delay_t;
extern void wallClockUpdate();
extern void wallClockWait(uint32_t mills);
extern uint32_t wallClockGetTimeMillis();
extern uint32_t timerMillis();

extern uint8_t wallClockNonBlockWait(uint32_t mills);
void timerDelay(uint32_t ms); 

extern uint32_t wallClockGetTimeMicros(TIM_TypeDef *TIMx);

void delay_ms(uint32_t ms);
void delay_us(uint32_t us);


#endif
