#ifndef MPU6500_H
#define MPU6500_H
#include <stdint.h>
#include "stm32f4xx_ll_utils.h"

#include "spi.h"

#define READ_FLAG 0x80 
#define WRITE_FLAG 0

typedef enum{
  WHO_AM_I,
  MPU6500_RESET,     //RESET DEVICE AND RESET SIGNALPATH
  SET_CLOCK_SOURCE,  //SET CLOCK SOURCE,DISABLE I2C, SAMPLE RATE DIVIDER
  MPU6500_CONFIG,   //CONFIG DLPF,GYRO,ACCEL,ACCEL2
  INT_ENABLE        //INTERRUPT ENBALE
}mpuInitState_t;

 
// GYRO FULL SCALE SELECT
typedef enum {
 GYRO_FS_250DPS =0,
 GYRO_FS_500DPS,
 GYRO_FS_1000DPS,
 GYRO_FS_2000DPS
}mpu6500GyroFs_t;

//ACCEL FULL SCALE SELECT
typedef  enum{
 ACCEL_FS_2G =0,
 ACCEL_FS_4G,
 ACCEL_FS_8G,
 ACCEL_FS_16G
}mpuAccelFs_t;

//dlpf
typedef  enum{
 DLPF_250HZ =0,
 DLPF_184HZ =1,
 DLPF_92HZ = 2,
 DLPF_41HZ = 3

}mpuDlpf_t;
 
typedef struct {
 int16_t ax,ay,az;
 int16_t gx,gy,gz;
 int16_t temp;

}mpu6500RawData_t;

typedef struct {
 float ax,ay,az;
 float gx,gy,gz;
 float temp;

}mpu6500Data_t; 
typedef  struct {
  spiPort_t spi;
  mpu6500Data_t mpuData;
  mpu6500RawData_t rawData;
  float gyroScale;
  float accelScale;
  uint8_t txBuffer[16];
  uint8_t rxbuffer[16];

  uint8_t smplrtDiv;
 

}mpu6500_t; 

extern mpu6500_t mpuint;

// Functions
void mpu6500Read(mpu6500_t *mpu, uint8_t reg, uint8_t len);
void mpu6500Write(mpu6500_t *mpu, uint8_t reg, uint8_t data, uint8_t len);
uint8_t mpu6500Init(mpu6500_t* mpu, uint32_t gyroFs, uint32_t accelFs, uint8_t smplrtDiv);
uint8_t mpu6500ReadData(mpu6500_t *mpu,uint8_t *data);

 //void mpu6500Write(mpu6500_t *mpu, uint8_t reg, uint8_t data)
#endif