#include "timer.h"

timer_t timer2, timer5;
timer_t wallClockTimer;


static const uint32_t PSC_VALUE[PSC_COUNT] = {
     PSC_VALUE_0,
     PSC_VALUE_99,
     PSC_VALUE_999,
     PSC_VALUE_9999,

};

uint8_t findTimerIndex(TIM_TypeDef *TIM){
  for(int timer_index = 0; timer_index < NUM_TIMERS; timer_index++){
      if(TIM == TIMER[timer_index])
        return timer_index;
  }

  return 0;
}

static void timerClockEnabler(TIM_TypeDef *TIMx){

if(TIMx == TIM1)
  LL_APB2_GRP1_EnableClock(LL_APB2_GRP1_PERIPH_TIM1);
else if(TIMx == TIM2)
  LL_APB1_GRP1_EnableClock(LL_APB1_GRP1_PERIPH_TIM2);
else if(TIMx == TIM3)
  LL_APB1_GRP1_EnableClock(LL_APB1_GRP1_PERIPH_TIM3);
else if(TIMx == TIM4)
  LL_APB1_GRP1_EnableClock(LL_APB1_GRP1_PERIPH_TIM4);
else if(TIMx == TIM5)
  LL_APB1_GRP1_EnableClock(LL_APB1_GRP1_PERIPH_TIM5);

}


void timerInit(timer_t *t,TIM_TypeDef *TIMx, float timerFreq_hz,uint32_t counterMode){ 

  uint8_t pscError = 0;

  LL_TIM_InitTypeDef TIM_InitStruct;

  t->index = findTimerIndex(TIMx);

  //PERIPHERAL CLOCK ENABLED IN SYSTEM CLOCK CONFIG - GENERALISE THIS
  timerClockEnabler(TIMx);
  
  t->busFreq = BUS_FREQUENCY[t->index];
  t->timerFreq = timerFreq_hz;
  t->counterResolution = COUNTER_RESOLUTION[t->index];
  t->counterMode = counterMode;
  
  uint64_t max_arr = (t->counterResolution == 16)? 0xFFFF : 0xFFFFFFFF;

   uint8_t i=0; 

  do{
     t->Prescaler =PSC_VALUE[i];
     t->AutoReload = (t->busFreq/(t->timerFreq*(t->Prescaler+1)))-1;
    if(t->AutoReload<= max_arr){
            pscError =1;
            break;
     }else{ 
       i++;
     }
   }while(i<PSC_COUNT);

  if(!pscError){
     debug_printf("ARR value is either less than or equal to zero or greater than the limit.\nset ARR value manually");
     return;
  }

  LL_TIM_StructInit(&TIM_InitStruct);
  TIM_InitStruct.Autoreload = t->AutoReload;
  TIM_InitStruct.ClockDivision = LL_TIM_CLOCKDIVISION_DIV1;
  TIM_InitStruct.Prescaler = t->Prescaler;
  TIM_InitStruct.CounterMode = t->counterMode;

  LL_TIM_Init(TIMx,&TIM_InitStruct);
  LL_TIM_DisableARRPreload(TIMx);
  LL_TIM_SetClockSource(TIMx, LL_TIM_CLOCKSOURCE_INTERNAL);
  LL_TIM_SetTriggerOutput(TIMx, LL_TIM_TRGO_RESET);
  LL_TIM_DisableMasterSlaveMode(TIMx);
  LL_TIM_EnableCounter(TIMx);

 return;
}




uint32_t timerAssignIrqn(TIM_TypeDef* TIMx)
{
   uint32_t IRQn =0;
  if (TIMx == TIM1)
    IRQn = TIM1_CC_IRQn;
  else if (TIMx == TIM2)
    IRQn = TIM2_IRQn;
  else if (TIMx == TIM3)
    IRQn = TIM3_IRQn;
  else if (TIMx == TIM4)
    IRQn = TIM4_IRQn;
  else if (TIMx == TIM5)
    IRQn = TIM5_IRQn;
  //else if (TIMx == TIM8)
  //  IRQn = TIM8_CC_IRQn;
  //else if (TIMx == TIM7)
  //  IRQn = TIM7_IRQn;
  return IRQn;
}

void timerInterruptEnable(TIM_TypeDef *TIMx,uint32_t setPriority){
  LL_TIM_EnableIT_UPDATE(TIMx);
  uint32_t irq = timerAssignIrqn(TIMx);
  NVIC_EnableIRQ(irq);
  NVIC_SetPriority(irq, setPriority);

}


void timerWallClockInit(timer_t *t,TIM_TypeDef *TIMx,uint32_t counterMode){
  LL_TIM_InitTypeDef TIM_InitStruct;

  t->index = findTimerIndex(TIMx);

  //PERIPHERAL CLOCK ENABLED IN SYSTEM CLOCK CONFIG - GENERALISE THIS
  timerClockEnabler(TIMx);
  //if(timerUtilization(TIMx))
  //   return;
  
  t->busFreq = BUS_FREQUENCY[t->index];
  t->counterResolution = COUNTER_RESOLUTION[t->index];
  t->counterMode = counterMode; 
  t->Prescaler = 83;
  t->AutoReload = 0xFFFFFFFF;

  LL_TIM_StructInit(&TIM_InitStruct);
  TIM_InitStruct.Autoreload = t->AutoReload;
  TIM_InitStruct.ClockDivision = LL_TIM_CLOCKDIVISION_DIV1;
  TIM_InitStruct.Prescaler = t->Prescaler;
  TIM_InitStruct.CounterMode = t->counterMode;

  LL_TIM_Init(TIMx,&TIM_InitStruct);
  LL_TIM_DisableARRPreload(TIMx);
  LL_TIM_SetClockSource(TIMx, LL_TIM_CLOCKSOURCE_INTERNAL);
  LL_TIM_SetTriggerOutput(TIMx, LL_TIM_TRGO_RESET);
  LL_TIM_DisableMasterSlaveMode(TIMx);
  LL_TIM_EnableCounter(TIMx);

}



//void timergpio(void){
//  RCC->AHB1ENR |= RCC_AHB1ENR_GPIOAEN;
//  GPIOA->MODER &= ~GPIO_MODER_MODE5;
//  GPIOA->MODER |= (0b01<<GPIO_MODER_MODE5_Pos);
//  GPIOA->AFR[0] &= ~GPIO_AFRL_AFRL5;
//  GPIOA->AFR[0] |= (0b0001<<GPIO_AFRL_AFSEL3_Pos);
//  GPIOA->OTYPER &= ~GPIO_OTYPER_OT5;
//  GPIOA->PUPDR &= ~GPIO_PUPDR_PUPD5;
//}



