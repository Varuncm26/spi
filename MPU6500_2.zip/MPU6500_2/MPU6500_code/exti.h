#ifndef EXTI_H
#define EXTI_H

#include "stm32f4xx_ll_exti.h"
#include "stm32f4xx_ll_gpio.h"
#include "stm32f4xx_ll_system.h"
#include "stm32f4xx_ll_bus.h"

// Change these to match the actual pin your MPU-6500 INT is wired to!
#define MPU_INT_PIN         LL_GPIO_PIN_0
#define MPU_INT_PORT        GPIOA
#define MPU_INT_EXTI_LINE   LL_EXTI_LINE_0
#define MPU_INT_IRQn        EXTI0_IRQn
#define MPU_SYSCFG_PORT     LL_SYSCFG_EXTI_PORTA
#define MPU_SYSCFG_LINE     LL_SYSCFG_EXTI_LINE0




typedef  struct{
  GPIO_TypeDef *extiPort;
  uint32_t extiPin;
}exti_t;
 
void extiInit(void);

#endif